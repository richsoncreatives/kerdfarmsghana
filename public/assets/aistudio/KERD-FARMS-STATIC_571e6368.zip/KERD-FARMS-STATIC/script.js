/* Lightweight static-site navigation behavior */
(() => {
  const toggles = Array.from(document.querySelectorAll(".shop-menu-toggle"));

  function closeAll(except) {
    toggles.forEach((button) => {
      if (button === except) return;
      const panel = document.getElementById(button.getAttribute("aria-controls"));
      button.setAttribute("aria-expanded", "false");
      if (panel) panel.hidden = true;
    });
  }

  toggles.forEach((button) => {
    const panel = document.getElementById(button.getAttribute("aria-controls"));
    if (!panel) return;
    button.addEventListener("click", (event) => {
      event.preventDefault();
      const opening = button.getAttribute("aria-expanded") !== "true";
      closeAll(button);
      button.setAttribute("aria-expanded", String(opening));
      panel.hidden = !opening;
    });
    button.addEventListener("keydown", (event) => {
      if (event.key === "ArrowDown") {
        event.preventDefault();
        button.click();
        panel.querySelector("a")?.focus();
      }
    });
    panel.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        panel.hidden = true;
        button.setAttribute("aria-expanded", "false");
        button.focus();
      }
    });
  });

  document.addEventListener("click", (event) => {
    if (!event.target.closest(".shop-menu-toggle") &&
        !event.target.closest(".shop-dropdown-panel")) closeAll();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeAll();
  });
})();
