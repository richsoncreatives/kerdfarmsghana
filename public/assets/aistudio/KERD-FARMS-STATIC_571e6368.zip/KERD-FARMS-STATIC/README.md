# Kerd Farms — Static Website

This folder contains the exported Kerd Farms pages converted to a static multi-page site.

## Files
- `index.html` — Home
- `about-us.html` — About Us
- `shop.html` — All products
- `poultry-eggs.html` — Poultry & Eggs
- `fruits-vegetables.html` — Fruits & Vegetables
- `seedlings-manure.html` — Seedlings & Manure
- `our-impact.html` — Our Impact
- `insight.html` — Insight
- `contact.html` — Contact
- `styles.css` — Extracted page styles and dropdown styling
- `script.js` — Shop dropdown behavior
- `assets/` — Local placeholder assets

## Deploy
Upload the contents of this folder to the root of a GitHub Pages or Cloudflare Pages static project. No build command is required.

## Notes
The original export was a SingleFile capture. Its captured styles and embedded image data are retained. platform-hosting URLs and export/router metadata have been removed and internal page links now use relative filenames. Forms or other features that depended on platform-hosted backend services are not recreated by a static export; those require a separate form/backend provider.
